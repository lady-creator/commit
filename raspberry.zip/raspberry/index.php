
<!DOCTYPE html>
<html>
<head>
	<title>lavamotique</title>
	<link rel="stylesheet" type="text/css" href="raspberr.css">
</head>
<body>
	<div class="container">
		<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
			<label for="nom">Nom :</label>
			<input class="t1"  type="text" name="nom" placeholder="Entrez le nom du client" id="nom" required><BR>

			<label for="prenom">Prénom :</label>
			<input class="t1" type="text" name="prenom" id="prenom" placeholder="Entrez le prénom du client" required><BR>

			<label for="teml">Téléphone :</label>
			<input class="t1" type="tel" name="tel" placeholder="Entrez le numéro de téléphone" id="tel" required><BR>

			<label for="">Poids Net :</label>
			<input class="t1" type="text" name="poids" required><BR>
			<label for="">Nombre de vêtement Blanc:</label>
			<input class="t1" type="text" name="POIDSB" required><BR>
				<?php $name = $_POST['poids']*350; ?>	 
			<label>Prix total :</label><br>  <h3><?php echo $name ?></h3>

			<!--<LABEL>PAYER?</LABEL><br>
			<input type="radio" name="p" value="oui"><LABEL for="oui" value="cheked">OUI</LABEL>
			<input type="radio" name="p" value="non"><label for="non">NON</label><br>-->
			<input type="submit" name=" envoyer" class="btn">
			<input type="reset" name="" class="btn">
		</form>
	</div>
	
</body>
</html>