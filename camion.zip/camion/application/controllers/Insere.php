<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class insere extends CI_Controller {

	public function __construct(){
	        parent::__construct();
	 
	        // load Pagination library
	        $this->load->library('pagination');
	         
	        // load URL helper
	        $this->load->helper('url');

	   		 }

	public function newadmin(){
		$data['titre'] = 'camion';
		$data['action']='insere/newadmin';
		$data['submit'] = 'Enregistrer';
		$data['tit']='creer un nouveau administrateur';
		
		//$data['admins'] = $this->M_admin->getadmin();
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('login', 'lang:login', 'strip_tags|trim|required|is_unique[admin.login]');
		
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'trim|required');
		$this->form_validation->set_rules('mot', 'lang:mot', 'trim|required');
		$this->form_validation->set_rules('cmdp', 'lang:cmdp', 'trim|required|matches[mot]');
		$this->form_validation->set_rules('tel', 'lang:tel', 'trim|required|min_length[9]|max_length[12]|numeric');


if($this->form_validation->run())
		{
		
$admin = array(
				'nom' => $this->input->post('nom'),
				'login' => $this->input->post('login'),
				'statut' => 'visiter',
				'n_tel' => $this->input->post('tel'),
				'date_naiss' => $this->input->post('date'),
				'ville' => $this->input->post('ville'),
				'mdp' => password_hash($this->input->post('mot'),PASSWORD_DEFAULT),
				'sexe' => $this->input->post('sexe'),
				'statut'=>'visiteur',
				'datesave' => date('Y-m-d'),
				'dateupdate' =>date('Y-m-d')
			);
			if($this->M_admin->addadmin($admin))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/');print_r($admin);
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('insere/newadmin');
				}
			
		}
		
		$this->load->view('newadmin', $data,false);

	}
	
///////////////////////////////////////////////pour inserer
	public function newcanion(){
		$data['titre'] = 'camion';
		$data['submit'] = 'Enregistrer';
		$data['action']='insere/newcanion';
		$data['tit']='créer un nouveau camion';
			$this->form_validation->set_rules('numero', 'lang:numero', 'strip_tags|trim|required|is_unique[camion.n_chaci]');
		$this->form_validation->set_rules('marque', 'lang:marque', 'strip_tags|trim|required');
		$this->form_validation->set_rules('model', 'lang:model', 'strip_tags|trim|required');
		$this->form_validation->set_rules('immatriculer', 'lang:immatriculer', 'strip_tags|trim|required|is_unique[camion.n_immatriculer]');
		if($this->form_validation->run())
		{
			$fich=array(
				'n_chaci'=>$this->input->post('numero'),
				'marque'=>$this->input->post('marque'),
				'model'=>$this->input->post('model'),
				'n_immatriculer'=>$this->input->post('immatriculer'),
				'datec'=>date('Y-m-d'),
				'idcf'=>$this->input->post('camion')
			);
			if($this->M_camion->addcamion($fich))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listecanion');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('insere/newcanion');
				}
			
		}
			$chauffe = $this->M_chauf->getchauf();
				$tabParent = array('0' =>'select_chauffeur');
				foreach($chauffe as $pts):
					$tabParent = $tabParent + array($pts->idcf => $pts->nom);
				endforeach;
				$data['chauf'] = $tabParent;
		$this->load->view('newcanion', $data);
	}
	
	public function newchauf(){
		$data['titre'] = 'camion';
		$data['submit'] = 'Enregistrer';
		$data['action']='insere/newchauf';
		$data['tit']='créer un nouveau chauffeur';
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required|alpha|is_unique[chauffeur.nom]');
		$this->form_validation->set_rules('prenom', 'lang:prenom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('tel', 'lang:tel', 'strip_tags|trim|required');
		$this->form_validation->set_rules('ville', 'lang:ville', 'strip_tags|trim|required');
		$this->form_validation->set_rules('date', 'lang:date', 'strip_tags|trim|required');
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'strip_tags|trim|required');
		if($this->form_validation->run())
		{
			$chauf=array(
				'nom'=>$this->input->post('nom'),
				'prenom'=>$this->input->post('prenom'),
				'sexe'=>$this->input->post('sexe'),
				'n_tel'=>$this->input->post('tel'),
				'ville'=>$this->input->post('ville'),
				'date_naiss'=>$this->input->post('date'),
				'datesave'=>date('Y-m-d'),
				'dateupdate'=>date('Y-m-d'),
				'statut'=>'on'
			);
			if($this->M_chauf->addchauf($chauf))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listechauf');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('insere/newchauf');
				}
			
		}
		$this->load->view('newchauf', $data);
	}

	public function newfiche(){
		$data['titre'] = 'camion';
		$data['submit'] = 'Enregistrer';
		$data['action']='insere/newfiche';
		$data['tit']='créer une nouvelle fiche';
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required|is_unique[fiche.nomf]');
		$this->form_validation->set_rules('idm', 'lang:idm', 'strip_tags|trim|required');
		$this->form_validation->set_rules('liste', 'lang:liste', 'strip_tags|trim|required');
		$this->form_validation->set_rules('detail', 'lang:detail', 'strip_tags|trim|required');
		
		if($this->form_validation->run())
		{
			$fich=array(
				'nomf'=>$this->input->post('nom'),
				'idm'=>$this->input->post('idm'),
				'liste_materiel'=>$this->input->post('liste'),
				'detail_r'=>$this->input->post('detail'),
				'datesave'=>date('Y-m-d'),
				'idc'=>$this->input->post('idc')
			);
		
			if($this->M_fiche->addfiche($fich))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listefiche');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					//redirect('insere/newfiche');
					print_r($fich);
				}
			
		}
		

		$mecanicien = $this->M_mecan->getmecan();
				$tabParent = array('0' => $this->lang->line('select_mecanicien'));
				foreach($mecanicien as $pts):
					$tabParent = $tabParent + array($pts->idm => $pts->nom);
				endforeach;
				$data['mecan'] = $tabParent;

				$camion = $this->M_camion->getcamion();
				$tabParent = array('0' => $this->lang->line('select_camion'));
				foreach($camion as $pt):
					$tabParent = $tabParent + array($pt->idc => $pt->n_immatriculer);
				endforeach;
				$data['camion'] = $tabParent;

$this->load->view('newfiche', $data);
	}
	public function newmecan(){
		$data['titre'] = 'camion';
		$data['submit'] = 'Enregistrer';
		$data['action']='insere/newmecan';
		$data['tit']='créer un nouveau mécanicien';
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required|alpha|is_unique[mecanicien.nom]');
		$this->form_validation->set_rules('prenom', 'lang:prenom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('numero', 'lang:numero', 'strip_tags|trim|required');
		$this->form_validation->set_rules('ville', 'lang:ville', 'strip_tags|trim|required');
		$this->form_validation->set_rules('date', 'lang:date', 'strip_tags|trim|required');
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'strip_tags|trim|required');
	
  
  if($this->form_validation->run())
		{
			$mecan=array(
				'nom'=>$this->input->post('nom'),
				'prenom'=>$this->input->post('prenom'),
				'sexe'=>$this->input->post('sexe'),
				'tel'=>$this->input->post('numero'),
				'ville'=>$this->input->post('ville'),
				'datenass'=>$this->input->post('date'),
				'datesave'=>date('Y-m-d'),
				'dateupdate'=>date('Y-m-d')
				
			);
			print_r($mecan);
			if($this->M_mecan->addmecan($mecan))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listemecan');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('accueil/listemecan');
				}		
		}
		$this->load->view('newmecan', $data);
	}

	///////////////////////////////////////////////pour inserer//////////////
	///////////////////////////////////////////////////////////////////////
	public function updateadmin($s){
		$data['titre'] = 'camion';
		$data['action']='insere/updateadmin/'.$s;
		$data['submit'] = 'Modifier';
		

		$data['tit']='Modifier les données administrateur';
		
		//$data['admins'] = $this->M_admin->getadmin();
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('login', 'lang:login', 'strip_tags|trim|required');
		
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'trim|required');
		$this->form_validation->set_rules('mot', 'lang:mot', 'trim|required');
		$this->form_validation->set_rules('cmdp', 'lang:cmdp', 'trim|required|matches[mot]');
		$this->form_validation->set_rules('tel', 'lang:tel', 'trim|required|min_length[9]|max_length[12]|numeric');


		if($this->form_validation->run())
		{
		
		$admin = array(
					'ida'=>$s,
				'nom' => $this->input->post('nom'),
				'login' => $this->input->post('login'),
				'statut' => 'visiter',
				'n_tel' => $this->input->post('tel'),
				'date_naiss' => $this->input->post('date'),
				'ville' => $this->input->post('ville'),
				'mdp' => password_hash($this->input->post('mot'),PASSWORD_DEFAULT),
				'sexe' => $this->input->post('sexe'),
				'statut'=>'visiteur',

				'dateupdate' =>date('Y-m-d')
			);
			if($this->M_admin->updateadmin($admin))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					//redirect('accueil/listecanion');
					//print_r($admin);
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					//redirect('insere/newcanion');
					redirect('accueil/listeadmin');
					print_r($admin);
				}
			
		}
		
		$this->load->view('newadmin', $data,false);

	}

	public function activeadmin($s){
		$data['titre'] = 'camion';
				$ad=$this->M_admin->getadmin(array('ida'=>$s));
				
				if($ad[0]->statut=='admin'){
					$admin = array(
						'ida'=>$s,
						'statut' =>'visiteur',
						
						'dateupdate' =>date('Y-m-d')
					);
				}else{
					$admin = array(
						'ida'=>$s,
						'statut' =>'admin',
						
						'dateupdate' =>date('Y-m-d')
					);
				}
				
		
			if($this->M_admin->updateadmin($admin))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listeadmin');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('accueil/listeadmin');
				}
			
		
		
		//$this->load->view('newadmin', $data,false);

	}

	public function updatecamion($m1){
		$data['titre'] = 'camion';
		$data['submit'] = 'Modifier';
		$data['action']='insere/updatecamion/'.$m1;
		$data['tit']='Modifier les données camion';
			$this->form_validation->set_rules('numero', 'lang:numero', 'strip_tags|trim|required');
		$this->form_validation->set_rules('marque', 'lang:marque', 'strip_tags|trim|required');
		$this->form_validation->set_rules('model', 'lang:model', 'strip_tags|trim|required');
		$this->form_validation->set_rules('immatriculer', 'lang:immatriculer', 'strip_tags|trim|required');
		if($this->form_validation->run())
		{
			$fich=array(
				'idc'=>$m1,
				'n_chaci'=>$this->input->post('numero'),
				'marque'=>$this->input->post('marque'),
				'model'=>$this->input->post('model'),
				'n_immatriculer'=>$this->input->post('immatriculer'),
				'datec'=>date('Y-m-d'),
				'idcf'=>$this->input->post('camion')
			);
			if($this->M_camion->updatecamion($fich))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listecanion');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('accueil/listecanion');
				}
			
		}
			$chauffe = $this->M_chauf->getchauf();
				$tabParent = array('0' =>'select_chauffeur');
				foreach($chauffe as $pts):
					$tabParent = $tabParent + array($pts->idcf => $pts->nom);
				endforeach;
				$data['chauf'] = $tabParent;
		$this->load->view('newcanion', $data);
	}
	
	public function updatechauf($m2){
		$data['titre'] = 'camion';
		$data['submit'] = 'Modifier';
		$data['action']='insere/updatechauf/'.$m2;
		$data['tit']='Modifier les données chauffeur';
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required');
		$this->form_validation->set_rules('prenom', 'lang:prenom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('tel', 'lang:tel', 'strip_tags|trim|required');
		$this->form_validation->set_rules('ville', 'lang:ville', 'strip_tags|trim|required');
		$this->form_validation->set_rules('date', 'lang:date', 'strip_tags|trim|required');
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'strip_tags|trim|required');
		if($this->form_validation->run())
		{
			$chauf=array(
				'idcf'=>$m2,
				'nom'=>$this->input->post('nom'),
				'prenom'=>$this->input->post('prenom'),
				'sexe'=>$this->input->post('sexe'),
				'n_tel'=>$this->input->post('tel'),
				'ville'=>$this->input->post('ville'),
				'date_naiss'=>$this->input->post('date'),
				'dateupdate'=>date('Y-m-d'),
				'statut'=>'on'
			);
			if($this->M_chauf->updatechauf($chauf))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listechauf');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('insere/updatechauf/'.$m2);
				}
			
		}
		$this->load->view('newchauf', $data);
	}

	public function updatefiche($m3){
		$data['titre'] = 'camion';
		$data['submit'] = 'Modifier';
		$data['action']='insere/updatefiche/'.$m3;
		$data['tit']='Modifier les données de la  fiche';
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required');
		
		$this->form_validation->set_rules('liste', 'lang:liste', 'strip_tags|trim|required');
		$this->form_validation->set_rules('detail', 'lang:detail', 'strip_tags|trim|required');
		if($this->form_validation->run())
		{
			$fich=array(
				'idf'=>$m3,
				'nom'=>$this->input->post('nom'),
				'idm'=>$this->input->post('idm'),
				'liste_materiel'=>$this->input->post('liste'),
				'detail_r'=>$this->input->post('detail'),
				'datesave'=>date('Y-m-d'),
				'idc'=>$this->input->post('idc')
			);

			if($this->M_fiche->updatefiche($fich))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('accueil/listefiche');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					
					redirect('insere/updatefiche/'.$m3);
				}
				
			
		}
		

		$mecanicien = $this->M_mecan->getmecan();
				$tabParent = array('0' => $this->lang->line('select_mecanicien'));
				foreach($mecanicien as $pts):
					$tabParent = $tabParent + array($pts->idm => $pts->nom);
				endforeach;
				$data['mecan'] = $tabParent;

				$camion = $this->M_camion->getcamion();
				$tabParent = array('0' => $this->lang->line('select_camion'));
				foreach($camion as $pt):
					$tabParent = $tabParent + array($pt->idc => $pt->n_immatriculer);
				endforeach;
				$data['camion'] = $tabParent;

$this->load->view('newfiche', $data);
	}
	public function updatemecan($m4){
		$data['titre'] = 'camion';
		$data['submit'] = 'Modifier';
		$data['action']='insere/updatemecan/'.$m4;
		$data['tit']='Modifier les données mécanicien';
		$this->form_validation->set_rules('nom', 'lang:nom', 'strip_tags|trim|required');
		$this->form_validation->set_rules('prenom', 'lang:prenom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('numero', 'lang:numero', 'strip_tags|trim|required');
		$this->form_validation->set_rules('ville', 'lang:ville', 'strip_tags|trim|required');
		$this->form_validation->set_rules('dates', 'lang:dates', 'strip_tags|trim|required');
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'strip_tags|trim|required');
	
  
  if($this->form_validation->run())
		{
			$mecan=array(
				'idm'=>$m4,
				'nom'=>$this->input->post('nom'),
				'prenom'=>$this->input->post('prenom'),
				'sexe'=>$this->input->post('sexe'),
				'tel'=>$this->input->post('numero'),
				'ville'=>$this->input->post('ville'),
				'datenass'=>$this->input->post('dates'),
			
				'dateupdate'=>date('Y-m-d')
				
			);
			print_r($mecan);
			if($this->M_mecan->updatemecan($mecan))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					//redirect('accueil/listemecan');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					//redirect('accueil/listemecan');
					print_r($mecan);
				}		
		}
		$this->load->view('newmecan', $data);
	}

}