
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accueil extends CI_Controller {

	public function __construct(){
	        parent::__construct();
	 
	        // load Pagination library
	        $this->load->library('pagination');
	         
	        // load URL helper
	        $this->load->helper('url');
	        if(!empty($_SESSION['ida'])){
				//redirect('');
						}
	   		 }

	public function welcome($f=NULL){

		
		//if(!empty($_SESSION['ida'])){
		$data['titre'] = 'camion';
		$this->load->library('pagination');
			 $config['base_url']=site_url('Accueil/listefiche');
			 	$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_fiche->getfiche());
				$this->pagination->initialize($config);
				 $nn=$this->input->get('nom');
				$data['fiche']=$this->M_fiche->geta($config['per_page'],'');
				
$this->load->view('wel', $data);
			
	

	}

	public function index()
		{
			$login = $this->input->post('login');
		$mdp =$this->input->post('mdp');
		$data['titre']='connexion';
		$this->form_validation->set_rules('mdp', 'mdp', 'trim|required');
		$this->form_validation->set_rules('login', 'lang:login', 'trim|required');

		$r=$this->M_admin->getadmin(array('login'=>$login));

		$data['cpte']='compte1';
		 $data['compte']="Merci d'entrée vos données";
	if($this->form_validation->run())
		{ print_r($r);
			 $data['compte']="Merci d'entrée vos données";
				$sess=array(
				'login'=>$r[0]->login,
				'nom'=>$r[0]->nom,
				'statut'=>$r[0]->statut,
				'ida'=>$r[0]->ida
				);
					if (password_verify($mdp, $r[0]->mdp) ){
		             	$this->session->set_userdata($sess);
		          		 redirect('index.php/accueil/welcome');
		        	}else{
		            $data['sess']='mot de passe incorrect';
		        		echo '<script>alert("veillez contacter l\'administrateur")</script>';
		            redirect('accueil');
		            
		       		 }
					
					 print_r($r);
				
			}

			$data['titre']='connexion';
			$this->load->view('index', $data);
		}


	public function listeadmin($f=NULL){

		if(!empty($_SESSION['ida'])){
				$data['titre'] = 'camion';
				$this->load->library('pagination');
				$ladmin=$this->M_admin->getadmin();
			 $config['base_url']=site_url('Accueil/listeadmin');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_admin->getadmin());
					$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$data['admin1']=$this->M_admin->getadmin();
				$this->pagination->initialize($config);
				$login=$this->input->get('login');	
				if(empty($login)){
							$data['admin']=$this->M_admin->geta($config['per_page'],$f);
				}else{
					$data['admin']=$this->M_admin->getadmin(array('login'=>$login));
				}

					$data['links']=$this->pagination->create_links();
		   		 $this->load->view('listeadmin', $data);
		    }else{
		    	redirect('');
		    }
	}

///////////////////////////////////////////////pour affichage
	public function listecanion($l=NULL){
		if(!empty($_SESSION['ida'])){
		$data['titre'] = 'camion';
		$this->load->library('pagination');
			 $config['base_url']=site_url('Accueil/listecanion');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_camion->getcamion());
					$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$this->pagination->initialize($config);
				
			
					$marque=$this->input->get('marque');
			$chaci=$this->input->get('chaci');
				/*if(!empty($chaci)&&!empty($chaci)){
					$data['camion']=$this->M_camion->gettout($l,$chaci,$marque);
				}elseif(!empty($chaci)&&empty($chaci)){
					$data['camion']=$this->M_camion->getcamion(array('chacis'=>$chaci));
				}elseif(empty($chaci)&&(!empty($chaci))){
					$data['camion']=$this->M_camion->getcamion(array());
				}else

				{*/
					$data['camion']=$this->M_camion->geta($config['per_page'],$l);
				//}

			$data['links']=$this->pagination->create_links();
		$this->load->view('listecanion', $data);
		}else{
		    	redirect('');
		    }
	}
	public function listechauf($lf=NULL){
		if(!empty($_SESSION['ida'])){
		$data['titre'] = 'camion';
		$this->load->library('pagination');
			 $config['base_url']=site_url('Accueil/listechauf');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_chauf->getchauf());
				$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$this->pagination->initialize($config);
			$data['chaufs']=$this->M_chauf->geta($config['per_page'],$lf);
			$chauf=$this->input->get('chauf');
			$nom=$this->input->get('nom');
				if($chauf=='All'&&empty($nom)){
							$data['chauf']=$this->M_chauf->geta($config['per_page'],$lf);
				}elseif($chauf=='All'&& (!empty($nom))){
						$data['chauf']=$this->M_chauf->getchauf(array('noms'=>$nom));
				}elseif($chauf!='All'&& (!empty($nom))){
						$data['chauf']=$this->M_chauf->getchauf(array('noms'=>$nom,'ville'=>$chauf));
				}else

				{
					$data['chauf']=$this->M_chauf->getchauf(array('ville'=>$chauf));
				}

			


			$data['links']=$this->pagination->create_links();
		$this->load->view('listechauf', $data);
		}else{
		    	redirect('');
		    }

	}

	public function listefiche($ll=NULL){
		if(!empty($_SESSION['ida'])){
		$data['titre'] = 'camion';
		$this->load->library('pagination');
			 $config['base_url']=site_url('Accueil/listefiche');
			 	$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_fiche->getfiche());
				$this->pagination->initialize($config);
				 $nn=$this->input->get('nom');
				$data['fiches']=$this->M_fiche->geta($config['per_page'],$ll);
					explode(' ', $nn);
				if($nn=='All'||empty($nn)){
					$data['fiche']=$this->M_fiche->geta($config['per_page'],$ll);
				}else{
					$data['fiche']=$this->M_fiche->getr($config['per_page'],$ll,$nn);
				}
			


			$data['links']=$this->pagination->create_links();
		$this->load->view('listefiche', $data);
		}else{
		    	redirect('');
		    }
	}

	public function affiche($idp){
			$fi=$this->M_camion->getcamion(array('idc'=>$idp));
			$fiche=$this->M_camion->tabfiche($fi);
			
			
					$data['fiche']=$this->M_camion->tabfiche($fi);
			
		
			$this->load->view('affiche',$data);
	}
	public function af_fiche($idp){
			$fi=$this->M_fiche->getfiche(array('idf'=>$idp));
			$fiche=$this->M_camion->tab_fiche($fi);
			if (count($fiche)	) {
					$data['fiche']=$this->M_camion->tab_fiche($fi);
			}else{
		show_404();
				}
		
			$this->load->view('affiche',$data);
	}
	public function listemecan($lm=NULL){
		if(!empty($_SESSION['ida'])){
		$data['titre'] = 'camion';
		$this->load->library('pagination');
			 $config['base_url']=site_url('Accueil/listemecan');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_mecan->getmecan());
				$config['first_link'] = 'First';
						$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$this->pagination->initialize($config);
				$data['mecans']=$this->M_mecan->geta($config['per_page'],$lm);
			$login=$this->input->get('login');
			$nom=$this->input->get('nom');
				if($login=='All'&&empty($nom)){
							$data['mecan']=$this->M_mecan->geta($config['per_page'],$lm);
				}elseif($login=='All'&& (!empty($nom))){
						$data['mecan']=$this->M_mecan->getmecan(array('noms'=>$nom));
				}elseif($login!='All'&& (!empty($nom))){
						$data['mecan']=$this->M_mecan->getmecan(array('noms'=>$nom,'login'=>$login));
				}else

				{
					$data['mecan']=$this->M_mecan->geta($config['per_page'],$lm);
				}

			$data['links']=$this->pagination->create_links();
		$this->load->view('listemecan', $data);
		}else{
		    	redirect('');
		    }
	}
	public function deconnexion(){
		session_destroy();
		redirect('');
	}
	public function newfiche(){
		$data['titre'] = 'camion';
		$this->load->library('pagination');
			 $config['base_url']=site_url('Accueil/listeadmin');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_admin->getadmin());
				$this->pagination->initialize($config);
			$data['fiche']=$this->M_admin->geta($config['per_page'],$f);


			$data['links']=$this->pagination->create_links();
		$this->load->view('newfiche', $data);
	}
		
	///////////:::::::::::--partie de la suppresion des donne
	public function deladmin($idp){
		
		$phot =$this->M_admin->getadmin(array('ida'=>$idp));

		if($this->M_admin->deleteadmin($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/Accueil/listeadmin');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/Accueil/listeadmin');
			}
		$this->load->view('Accueil/produit/');
		
	}
	
	public function delchauf($idp){
		if($this->M_chauf->deletechauf($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/Accueil/listechauf');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/Accueil/listechauf');
			}
		$this->load->view('chauf/produit/');
		
	}
	public function delfiche($idp){
		if($this->M_fiche->deletefiche($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/Accueil/listefiche');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/Accueil/listefiche');
			}
		$this->load->view('fiche/produit/');
		
	}
	public function delmecan($idp){

		if($this->M_mecan->deletemecan($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/accueil/listemecan');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/Accueil/listemecan');
			}
		$this->load->view('mecan/produit/');
		
	}
	public function delcamion($idp){
		if($this->M_camion->deletecamion($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/accueil/listecnion');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/Accueil/listecanion');
			}
	}
	

}