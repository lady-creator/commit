
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accueil extends CI_Controller {

	public function __construct(){
	        parent::__construct();
	 
	        // load Pagination library
	        $this->load->library('pagination');
	         
	        // load URL helper
	        $this->load->helper('url');
	   		 }
public function index($f=NULL){
		$data['titre'] = 'camion';


		$this->load->view('index', $data);
	}
		
	public function deladmin($idp){
		
		$phot =$this->M_admim->getadmin(array('ida'=>$idp));

		if($this->M_admin->deladmin($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('accueil/listeadmin');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('Accueil/listeadmin');
			}
		$this->load->view('admin/produit/');
		
	}
	public function delchauf($idp){
		
		//$phot =$this->M_admim->getPhoto(array('ida'=>$idp));

		if($this->M_chauf->delchauf($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('accueil/listechauf');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('Accueil/listechauf');
			}
		$this->load->view('chauf/produit/');
		
	}
	public function delfiche($idp){
		
		//$phot =$this->M_admim->getPhoto(array('ida'=>$idp));

		if($this->M_fiche->delfiche($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('accueil/listefiche');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('Accueil/listefiche');
			}
		$this->load->view('fiche/produit/');
		
	}
	public function delmecan($idp){
		
		//$phot =$this->M_admim->getPhoto(array('ida'=>$idp));

		if($this->M_mecan->delmecan($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('accueil/listemecan');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('Accueil/listemecan');
			}
		$this->load->view('mecan/produit/');
		
	}

}