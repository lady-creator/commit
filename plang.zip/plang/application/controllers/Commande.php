<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Commande extends CI_Controller {

	public function index()
	{
		  $data['commandes'] = $this->M_commande->getCommande();
		$data['titre'] = $this->lang->line('affich_cmd');
		$this->load->view('commande/liste', $data);
	}

	public function inde($cmd=NULL)
	{
		
		//selectionne la commande
		$cons = $this->M_commande->getCommande(array('codecmd'=>$cmd));
		if(count($cons)){
		$data['commandes']=$this->M_commande->tabcmd($cons);
		// selectionne les produits de la commande
		$con = $this->M_commande->getConstituant(array('codecmd'=>$cons[0]->codecmd)); 

		$data['const']=$this->M_commande->tabcons($con);
		//print_r($data['const']);
		
		$data['titre'] = $this->lang->line('affich_cmd');


		}else{
		show_404();
	}
		$this->load->view('commande/listeA', $data);
	}

	public function ajouter()
	{
		$this->form_validation->set_rules('nomcl', 'lang:nomcl', 'trim|required');
		$this->form_validation->set_rules('emailcl', 'lang:emailcl', 'trim|required|valid_email');
		$this->form_validation->set_rules('telephonecl', 'lang:telephonecl', 'trim|required|min_length[9]|max_length[12]|numeric');
		$this->form_validation->set_rules('villeliv', 'lang:villeliv', 'trim|required');
		$this->form_validation->set_rules('quatiercl', 'lang:quatiercl', 'trim|required');
		$this->form_validation->set_rules('prenomcl', 'lang:prenomcl', 'trim|required');
		$this->form_validation->set_rules('adressedeliv', 'lang:adressedeliv', 'trim|required');
				$i=0;
				if(!empty($_SESSION['id']))
				{
					 $i=$_SESSION['id'];
				}else{
					 $i=0;
				}	
		 $ran=rand(9999,99999);
		if($this->form_validation->run())
		{
		    $cmd=array(
		    'codecmd'=>$ran,
			//'idclient'=>$this->input->post('idclient'),
			'idclient'=>$i,
			'datecmd'=>date('Y-m-d H:i:s'),
			'statutcmd'=>'begin',
			'ptcmd'=>'875',
			'modliv'=>$this->input->post('modliv'),
			'datepay'=>date('Y-m-d H:i:s'),
			'modepay'=>$this->input->post('modepay'),
			'datesavecmd'=>date('Y-m-d'),
			'dateupdatecmd'=>date('Y-m-d'),
			'adressedeliv'=>$this->input->post('adressedeliv'),
			'nomcl'=>$this->input->post('nomcl'),
			'prenomcl'=>$this->input->post('prenomcl'),
			'telephonecl'=>$this->input->post('telephonecl'),
			'emailcl'=>$this->input->post('emailcl'),
			'villeliv'=>$this->input->post('villeliv'),
			'quatiercl'=>$this->input->post('quatiercl'),
			'prixl'=>'500'
			);
			$this->config->load('email', TRUE);
			//$this->email->from('florinesiewe@gmail.com', 'client');
			$this->email->to('florinesiewe@gmail.com');
			$this->email->subject('commande');
			$this->email->message('une commande a été effectué');

		 	foreach ($this->cart->contents() as $cons) {
			    	$const=array(
			    	'idpt'=>$cons['id'],
					'ptconst'=>$cons['prixapt'],
					'qteconst'=>$cons['qtept'],
					'codecmd'=>$cmd['codecmd']
					
					);
			    	$this->M_commande->addconstituant($const);
			};
		
			if($this->M_commande->addCommande($cmd))
			{
				$this->email->send();
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('Commande/finir');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('commande/ajouter');
			}
			
		}
				$data['valider']='valider la commande';
		$data['action'] = 'Commande/ajouter/';
		$data['titre'] = $this->lang->line('ajouter_cmd');
		$this->load->view('commande/ajouter', $data);
	}

	public function modifier($cmd){
		$data['titre'] = $this->lang->line('modif_cm');
		$cmds=$this->M_commande->getCommande(array('codecmd'=>$cmd));
		$cmds=array(
		    'codecmd'=>$cmd,		
			'statutcmd'=>$this->input->post('statut'),
			'dateupdatecmd'=>date('Y-m-d')
		);
			
		if($this->M_commande->updateCommande($cmds))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('commande/inde/'.$cmd);
			}
	}
	///modification de la commande complete
	public function modifcmd($code)
	{
		$this->form_validation->set_rules('nomcl', 'lang:nomcl', 'trim|required');
		$this->form_validation->set_rules('emailcl', 'lang:emailcl', 'trim|required|valid_email');
		$this->form_validation->set_rules('telephonecl', 'lang:telephonecl', 'trim|required|min_length[9]');
		$this->form_validation->set_rules('villeliv', 'lang:villeliv', 'trim|required');
		$this->form_validation->set_rules('quatiercl', 'lang:quatiercl', 'trim|required');
		$this->form_validation->set_rules('prenomcl', 'lang:prenomcl', 'trim|required');
		$this->form_validation->set_rules('adressedeliv', 'lang:adressedeliv', 'trim|required');
				
		if($this->form_validation->run())
		{
		    $cmd=array(
			'datecmd'=>date('Y-m-d H:i:s'),
			'statutcmd'=>'begin',
			'ptcmd'=>'875',
			'modliv'=>$this->input->post('modliv'),
			'datepay'=>date('Y-m-d H:i:s'),
			'modepay'=>$this->input->post('modepay'),
			'dateupdatecmd'=>date('Y-m-d'),
			'adressedeliv'=>$this->input->post('adressedeliv'),
			'nomcl'=>$this->input->post('nomcl'),
			'prenomcl'=>$this->input->post('prenomcl'),
			'telephonecl'=>$this->input->post('telephonecl'),
			'emailcl'=>$this->input->post('emailcl'),
			'villeliv'=>$this->input->post('villeliv'),
			'quatiercl'=>$this->input->post('quatiercl'),
			);
		 /*	foreach ($this->cart->contents() as $cons) {
			    	$const=array(
			    	'idpt'=>$cons['id'],
					'ptconst'=>$cons['prixapt'],
					'qteconst'=>$cons['qtept'],
					'codecmd'=>$cmd['codecmd']
					
					);
			    	$this->M_commande->updateconstituant($const);
			};
		*/
			if($this->M_commande->updateCommande($cmd))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('commande/finir');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('commande/modifcmd/57612');
			}
			
		}
		$data['commandes'] = $this->M_commande->getCommande(array('codecmd'=>$code));
				$data['valider']='Modifier la commande';
		$data['action'] = 'commande/modifcmd/'.$code;
		$data['titre'] = $this->lang->line('ajouter_cmd');
		$this->load->view('commande/ajouter', $data);
	}
	///////////////////////////////
	public function modif($cmd){
		$data['titre'] = $this->lang->line('modif_cm');
		$cmds=$this->M_commande->getCommande(array('codecmd'=>$cmd));
		$this->form_validation->set_rules('prix', 'lang:prix', 'trim|required');
		if($this->form_validation->run()){
				
		
		if(count($cmds)){
		$cmds=array(
		    'codecmd'=>$cmd,
			'prixl'=>$this->input->post('prix'),
			'dateupdatecmd'=>date('Y-m-d')
		);	
		if($this->M_commande->updateCommande($cmds))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('commande/inde/'.$cmd);	
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('commande/inde/'.$cmd);
				
			}
	}else{
		show_404();
	}
 		}
	}
	public function finir()
	{
		$data['commandes'] = $this->M_commande->getCommande(array('limit'=>'0','order'=>' ','codecmd','code'=>' '));
		$data['titre'] = 'merci a vous';
		$this->load->view('commande/success',$data );
	}
	public function facture($cmd)
	{
		
		//selectionne la commande
		if($_SESSION['id']!==NULL){
		$cons = $this->M_commande->getCommande(array('codecmd'=>$cmd));
		if(count($cons)){
		$data['commandes']=$this->M_commande->tabcmd($cons);
		// selectionne les produits de la commande
		$con = $this->M_commande->getConstituant(array('codecmd'=>$cons[0]->codecmd)); 

		$data['const']=$this->M_commande->tabcons($con);
		//print_r($data['const']);
		
		$data['titre'] = $this->lang->line('affich_cmd');
		}else{
		show_404();
		}
			
			$this->load->view('commande/factur', $data);
			}else{
				redirect('admin/administrateur');
						}
		}


	


           public function search(){
           	if($_SESSION['id']!==NULL){
			$this->form_validation->set_rules('nom', 'lang:nom', 'trim|htmlspecialchars|required');
           	if($this->form_validation->run())
			{	
				$nom=$this->input->post('nom');

		   $data['s'] = $this->M_commande->getCommande(array('codecmd'=>$nom));
      		  }
			$data['titre'] = 'planG';

			$this->load->view('commande/search', $data);
				}else{
				redirect('admin/administrateur');
						}
				}
	}