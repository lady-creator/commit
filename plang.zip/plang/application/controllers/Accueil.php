
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accueil extends CI_Controller {

	public function __construct(){
	        parent::__construct();
	 
	        // load Pagination library
	        $this->load->library('pagination');
	         
	        // load URL helper
	        $this->load->helper('url');
	   		 }

	public function index(){
		$data['titre'] = 'accueil_planG';
		//selectionner tous les articles
		$produit = $this->M_produit->getProduit(array('statutpt' =>'approuver'));
		
		$data['prod'] = $this->M_produit->tabProduit($produit);

		//selectionner les articles qui n'ont pas été visité
		$produits = $this->M_produit->getProduit(array('iprix' =>'50000','statutpt' =>'approuver'));
		$data['prod'] = $this->M_produit->tabProduit($produits);

		//selectionner les article les plus populaire
		$visites=$this->M_produit->getVisite(array('sup'=>'5'));
		$data['vs'] = $this->M_produit->tabPvisite($visites);
		//selectionner les article les moins populaire
		$visites=$this->M_produit->getVisite(array('inf'=>'8'));
		$data['vi'] = $this->M_produit->tabPvisite($visites);

		//selectionner les deniers articles
		$produi = $this->M_produit->getProduit(array('order'=>'ipdt','statutpt' =>'approuver'));
		
		$data['prodf'] = $this->M_produit->tabProduit($produi);
		// les fornisseurs
		$produi = $this->M_produit->getProduit(array('order'=>'datesavept','statutpt' =>'approuver'));
        $data['four'] = $this->M_fournisseur->getFournisseur(array('nomfour'));
        //selectionné les categories
        $produits = $this->M_produit->getProduit(array('codecat'=>'canape'));
		$data['canape'] = $this->M_produit->tabProduit($produits);
		$this->load->view('accueil', $data);
	}
		public function produit($idpt)
		{
			$data['titre'] = 'planG';
			$data['p1'] = $this->M_produit->getProduit(array('idpt' =>$idpt,'statutpt' =>'approuver'));
			//	print_r($produits);
			//selection le produit qui est sélectionné
			if(count($data['p1'])){
				$produits = $this->M_produit->getProduit(array('idpt' =>$idpt,'statutpt' =>'approuver'));
				$p=$data['p'] = $this->M_produit->tabProduit($produits);

				//selection tout les produits
				$produit = $this->M_produit->getProduit(array('iprix' =>'100000','nidpt'=>$idpt));
				$data['prod'] = $this->M_produit->tabProduit($produit);
				// selectionner tous les produits sauf celui en parametre
			
			
				// selection les similaire à un produit à celui de l'id
				foreach ($produits as $ps) {
					$ps->codecat;	
					}
				$produi = $this->M_produit->getProduit(array('nidpt'=>$idpt,'codecat' =>$ps->codecat));
				$pp=$data['ps'] = $this->M_produit->tabProduit($produi);

				// selectionner tous les produits sauf celui en parametre
				$produi = $this->M_produit->getProduit(array('nidpt' =>$idpt,'ncode' =>$ps->codecat));
				$data['nprod'] = $this->M_produit->tabProduit($produi);

				/* ################### page :: table visite ################### */
				$visite=$this->M_produit->getVisite(array('idpt'=>$idpt));
				if(count($visite)){
					foreach ($visite as $v) {
						$v->nbv;
						$v->dates;
					}
					$vs=array(
						'idv'=>$visite[0]->idv,
						'idpt'=>$idpt,
						'nbv'=>$v->nbv+1,
						'dates'=>$v->dates,
						'dateupdate'=>date('Y-m-d H:i:s')
					);
					$this->M_produit->updateVisite($vs);
				}else
					{
					$i=1;
					$vs=array(
						'idpt'=>$idpt,
						'nbv'=>$i,
						'dates'=>date('Y-m-d'),
						'dateupdate'=>date('Y-m-d H:i:s')
					    );
				    $this->M_produit->addVisite($vs);
				}
			}else{
				show_404();
			}

			$this->load->view('produit', $data);
		}
/* ###################                      ################### */

/* ################### page :: le controller du panier ################### */
		public function panier()
		{
			$data['titre'] = 'planG';
			$this->load->view('panier',$data);
		}
		public function categorie($codecat)
		{
			$categories = $this->M_categorie->getCategorie(array('codecat' =>$codecat,'statutpt' =>'approuver'));
			$data['p']=$this->input->post('prix');
				print_r($data['p']);
				$p=$this->input->get('p');
				$c=$this->input->get('c');
				
				if($p=='all'){
					
				
				//$produits = $this->M_produit->getProduit(array('statutpt' =>'approuver'));
				$produits = $this->M_produit->getProduit(array($this->db->where('codecat ' ,$codecat)));
				$data['phot'] = $this->M_produit->tabProduit($produits);
		
					
		}elseif ($p=='asc') {
			$produits = $this->M_produit->getProduit(array('asc'=>'','codecat' =>$codecat));
				$data['phot'] = $this->M_produit->tabProduit($produits);
		}else{
			$produits = $this->M_produit->getProduit(array('desc'=>'','codecat' =>$codecat));
				$data['phot'] = $this->M_produit->tabProduit($produits);
		}

		
		if($c=='autre'){
					
				$produits = $this->M_produit->getProduit(array('codecat' =>$codecat));
				$data['phot'] = $this->M_produit->tabProduit($produits);
					
		}elseif ($c='blanc') {
			$produits = $this->M_produit->getProduit(array('couleurpt'=>$c,'codecat' =>$codecat));
				$data['phot'] = $this->M_produit->tabProduit($produits);
		}else{
			
				$produits = $this->M_produit->getProduit(array('couleurpt'=>$c,'codecat' =>$codecat));
				$data['phot'] = $this->M_produit->tabProduit($produits);
		}

		if($p==''|| $c=='')
		{
			$produits = $this->M_produit->getProduit(array($this->db->where('codecat ' ,$codecat)));
				$data['phot'] = $this->M_produit->tabProduit($produits);

		}

			$data['titre'] = 'planG';
			$this->load->view('categorie', $data);
		}

		
		public function email()
		{
			$data['titre'] = 'planG';
			$this->form_validation->set_rules('sms', 'lang:sms', 'required');
			$this->form_validation->set_rules('objet', 'lang:objet', 'required');
     		$this->form_validation->set_rules('email', 'lang:email', 'trim|htmlspecialchars|required|valid_email');
			if($this->form_validation->run())
			{		 //Mail settings
	        	$this->config->load('email', TRUE);
				$email=$this->input->post('email');
				$sms=$this->input->post('sms');
				$obet=$this->input->post('objet');
				$this->email->from($email, 'client');
				$this->email->to('florinesiewe@gmail.com');
				$this->email->subject($obet);
				$this->email->message($sms);
				if($this->email->send()){
					    redirect('');
					}else{
					    echo $this->email->print_debugger();
					}
			
			}
		    $this->load->view('email', $data);
		}
			public function search($offset=0){
			$n=$this->input->get('nom');
			$nom= !empty($this->input->get('nom'))?$this->input->get('nom'):" ";
			$data['tt']=$tt=explode(" ",$nom);

				$nom= $this->input->get('nom');
			if($nom==""){
					redirect('');
				}else{
					
						$produit = $this->M_produit->getProduit(array('search'=>$n));
						$this->load->library('pagination');
			            $config['base_url'] = base_url('Accueil/search');
			            $config['total_rows'] = count($produit);
			            $config['per_page'] = 8;
			         
			            
			            // custom paging configuration
			          
			           
			            $config['reuse_query_string'] = TRUE;
			            
			             // $results= $this->M_produit->getAll( $config['per_page'],$offset);
			            //$data['prod'] = $this->M_produit->tabProduit($results); 
			            // custom paging configuration
			         $config['full_tag_open'] = '<div class="pagination sdsds">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink">';
						$config['num_tag_close'] = '</button>';
			              $results= $this->M_produit->getAll(array('search'=>$n),$config['per_page'],$offset);
			            $data['prod'] = $this->M_produit->tabProduit($results); 
			            $this->pagination->initialize($config);
			                 
			            // build paging links
			            $data["links"] = $this->pagination->create_links();
			            $data["titre"]="recherche";
			              //$this->load->view('search', $data);
			           
			             $this->load->view('search', $data);
			            //print_r($data["links"] );
			           
			      }	
				
				
		
	
}

	public function retour(){
		$data['titre']="retour";
		$this->load->view('retour',$data);
		}
		/*public function search($nom=NULL){
			$n=$this->input->get('nom');
			$nom= !empty($this->input->get('nom'))?$this->input->get('nom'):" ";
			$tt=explode(" ",$nom);
				print_r($tt[0]);

				$nom= $this->input->get('nom');
				//if($nom==""){
				//	redirect('');
				//}else{
				
					
					//$mot=explode(" ",$nom);
					//print_r($mot);
					//foreach ($mot as $n) {
						$produit = $this->M_produit->getProduit(array('search'=>$nom));

					
					$data["links"]= $this->pagination->create_links();

					$limit_per_page = 15;
			        $page = ($this->uri->segment(3)) ? ($this->uri->segment(3) - 1) : 0;
			     
			        if (count($produit))
			        {
			            // get current page records
			            $results= $this->M_produit->getProduit(array('limits'=>' ','search'=>$nom));
			            $data['prod'] = $this->M_produit->tabProduit($results); 
  
			            $config['base_url'] = base_url('Accueil/search');
			            $config['total_rows'] = count($produit);
			            $config['per_page'] = $limit_per_page;
			            $config["uri_segment"] = 3;
			             
			            // custom paging configuration
			            $config['num_links'] = 4;
			            $config['use_page_numbers'] = TRUE;
			            $config['reuse_query_string'] = TRUE;
			             
			            $config['full_tag_open'] = '<div class="pagination">';
			            $config['full_tag_close'] = '</div>';
			             
			            $config['first_link'] = 'First Page';
			            $config['first_tag_open'] = '<span class="firstlink">';
			            $config['first_tag_close'] = '</span>';
			             
			            $config['last_link'] = 'Last Page';
			            $config['last_tag_open'] = '<span class="lastlink">';
			            $config['last_tag_close'] = '</span>';
			             
			            $config['next_link'] = 'Next Page';
			            $config['next_tag_open'] = '<span class="nextlink">';
			            $config['next_tag_close'] = '</span>';
			 
			            $config['prev_link'] = 'Prev Page';
			            $config['prev_tag_open'] = '<span class="prevlink">';
			            $config['prev_tag_close'] = '</span>';
			 
			            $config['cur_tag_open'] = '<span class="curlink">';
			            $config['cur_tag_close'] = '</span>';
			 
			            $config['num_tag_open'] = '<span class="numlink">';
			            $config['num_tag_close'] = '</span>';
			             
			            $this->pagination->initialize($config);
			                 
			            // build paging links
			            $data["links"] = $this->pagination->create_links();
			            $data["titre"]="recherche";
			            //print_r($data["links"] );
			            $this->load->view('search', $data);
			        }//else{
			        //	redirect('');
			        //}	
				//}
	}
				
		
	
}*/
		

}