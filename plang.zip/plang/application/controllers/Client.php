<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {
	function _contruct(){
		parent::_contruct();
		$this->sessionUser();
	}
	
	public function index()
	{
		if($_SESSION['id']!==NULL){
		$data['clients'] =$this->M_client->getClient();

		$data['titre'] = $this->lang->line('affich_clt');
		$this->load->view('client/liste',$data );
		}else{
				redirect('admin/administrateur');
						}
	}

	public function ajouter()
	{
		if($_SESSION['id']!==NULL){
		$this->form_validation->set_rules('nomclt', 'lang:nomclt', 'trim|required');
		$this->form_validation->set_rules('datenaissclt', 'lang:datenaissclt', 'trim|required');
		$this->form_validation->set_rules('mdpclt', 'lang:mdpclt', 'trim|required');
		$this->form_validation->set_rules('emailclt', 'lang:emailclt', 'trim|required|valid_email');
		$this->form_validation->set_rules('mdpclt', 'lang:mdpclt', 'trim|required|is_unique[client.mdpclt]|min_length[6]');
		$this->form_validation->set_rules('cmdp', 'lang:mdpclt', 'trim|required|matches[mdpclt]');
		$this->form_validation->set_rules('telclt', 'lang:telephonecl', 'trim|required|min_length[9]|max_length[12]|numeric');
		$this->form_validation->set_rules('prenomclt', 'lang:prenomclt', 'trim|required');
		$this->form_validation->set_rules('quartierclt', 'lang:quartierclt', 'trim|required');
		if($this->form_validation->run())
		{
			$mdp=$this->input->post('mdpclt');
			$client = array(
				'nomclt' => strtoupper($this->input->post('nomclt')),
				'prenomclt' => strtoupper($this->input->post('prenomclt')),
				'datenaissclt' => $this->input->post('datenaissclt'),
				'villeclient' => strtoupper($this->input->post('villeclient')),
				'sexeclt' => $this->input->post('sexeclt'),
				'emailclt' => $this->input->post('emailclt'),
				'mdpclt' => password_hash($mdp,PASSWORD_DEFAULT),
				'telclt' => $this->input->post('telclt'),
				'statutclt' => 'connect',
				'quartierclt' => strtoupper($this->input->post('quartierclt')),
				'datesaveclt' => date('Y-m-d'),
				'dateupdateclt' => date('Y-m-d'),
			);

			if($this->M_client->addClient($client))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('client/ajouter');
			}
		}
		$data['titre'] = $this->lang->line('ajouter_client');
		$this->load->view('client/ajouter', $data);
		}else{
				redirect('admin/administrateur');
						}
	}

	public function modifier()
	{
		
		$data['titre'] = ' nouveau Client';
		$this->load->view('fom',$data );
	}

	public function connexion(){
		$data['titre']='espace client';
		$emailclt = $this->input->post('emailclt');
		$mdpclt =$this->input->post('mdpclt');

		$client=$this->M_client->getClient(array('emailclt'=>$emailclt));
		$this->form_validation->set_rules('emailclt', 'lang:emailclt', 'trim|required|valid_email');
		$this->form_validation->set_rules('mdpclt', 'lang:mdpclt', 'trim|required');

	if($this->form_validation->run()){
		if(count($client)){
			if (password_verify($mdpclt, $client[0]->mdpclt) ){
				$user=array(
			'id' => $client[0]->idclient,
			'username' => $client[0]->nomclt,
			'user' => 'client',
			'email'=>$client[0]->emailclt,
			'tel'=>$client[0]->telclt,
			'name'=>$client[0]->prenomclt,
			'quartier'=>$client[0]->quartierclt
			);
				$this->session->set_userdata ($user );
				if($_SESSION['id']!==NULL){
					redirect(' ');

					}
		}else{
			
			$data['users']= "Vérifier votre mod de passe";
		}
		}else{
			$data['users']= "Vérifier votre adresse mail";
		}	
		}
		$data['titre'] = 'palnG\client';
	$this->load->view('client/login',$data);
	}
	public function oublier(){
		$data['action']='client/oublier';
		$emailclt = $this->input->post('emailclt');
		$this->form_validation->set_rules('emailclt', 'lang:emailclt', 'htmlspecialchars|trim|required|valid_email');
		$client=$this->M_client->getClient(array('emailclt'=>$emailclt));
		$user=array(
			'id' => $client[0]->idclient,
			'username' => $client[0]->nomclt,
			'user' => 'client',
			'email'=>$client[0]->emailclt,
			'tel'=>$client[0]->telclt,
			'name'=>$client[0]->prenomclt,
			'quartier'=>$client[0]->quartierclt
			);
				$this->session->set_userdata ($user );

				//print_r($client)
		if($this->form_validation->run()){
			if (count($client)){
				if($client[0]->emailclt==$emailclt){
					
				}
			}else{
				$data['user']='Verifiez votre adresse Mail ,vous n\'existez chez nous';
			}
		}
		$data['titre']=$this->lang->line('plang');
		$this->load->view('client/M_oublier',$data);

	}
	public function deconnexion(){
		$sess = array('tel',
			'cart_contents', 
			'email','username','quartier','id','name','__ci_last_regenerate');
		$this->session->unset_userdata($sess);
		redirect('');
	}
}