<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categorie extends CI_Controller {
/* ################### page :: methode pour lister ################### */
	public function index($offset=0)
	{ 
		if($_SESSION['id']!==NULL){
		$cat=$data['categories'] = $this->M_categorie->getCategorie();
		$this->load->library('pagination');
		$config['base_url'] = site_url('admin/categorie/index');
		$config['total_rows'] = count($cat);
		$config['per_page'] = 8;
		$config['reuse_query_string'] = TRUE;
		$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
		$this->pagination->initialize($config);
		$data['categories'] = $this->M_categorie->getAl($config['per_page'],$offset);
		$data['links']=$this->pagination->create_links();
		$data['titre'] = 'Listes des categories';
		$this->load->view('categorie/liste', $data);
		}else{
				redirect('admin/administrateur');
						}
	}
/* ################### page :: methode pour ajouter ################### */
	public function ajouter()
	{
		if($_SESSION['id']!==NULL){
		$this->form_validation->set_rules('nomcat', 'lang:nomcat', 'trim|required');
		$data['action']='admin/categorie/ajouter';
		$data['submit']=$this->lang->line('AJOUTER');
		$data['categorie']= $this->M_categorie->getCategorie();
		if($this->form_validation->run())
		{
			$categorie = array(
				'parent' => $this->input->post('parent'),
				'nomcat' => $this->input->post('nomcat'),
				'codecat' => url_title($this->input->post('nomcat'), 'underscore', TRUE),
				'datesavectg' => date('Y-m-d'),
				'dateupdatectg' => date('Y-m-d'),
			);

			if($this->M_categorie->addCategorie($categorie))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/Categorie/ajouter');
			
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/categorie/ajouter');
			}
		}

		$parents = $this->M_categorie->getCategorie(array('parent' => '0'));
		$tabParent = array('0' => $this->lang->line('select_parent'));
		foreach($parents as $pts):
			$tabParent = $tabParent + array($pts->codecat => $pts->nomcat);
		endforeach;
		$data['parent'] = $tabParent;
		$data['titre'] = $this->lang->line('ajouter_cat');
		$this->load->view('categorie/ajouter', $data);
		}else{
				redirect('admin/administrateur');
						}
			
	}

	public function modifier($codecat)
	{
		if($_SESSION['id']!==NULL){
		$data['titre'] = $this->lang->line('modif_cat');
		$data['submit'] = $this->lang->line('MODIFIER');
		$data['action']='admin/Categorie/modifier/'.$codecat;
		$ros=$data['categorie']= $this->M_categorie->getCategorie(array('codecat'=>$codecat));
		if($this->form_validation->run())
		{
			foreach ($ros as $v) {
					$v->dateupdatectg;
				}
			$categorie = array(
				'parent' => $this->input->post('parent'),
				'nomcat' => $this->input->post('nomcat'),
				'codecat' => $codecat,
				'datesavectg' => date('Y-m-d'),
				'dateupdatectg' => date('Y-m-d'),
			);

			if($this->M_categorie->updateCategorie($categorie))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/Categorie/liste');
			
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				show_404();
				//redirect('admin/categorie/ajouter');
			}
		}
			$parents = $this->M_categorie->getCategorie(array('parent' => '0'));
		$tabParent = array('0' => $this->lang->line('select_parent'));
		foreach($parents as $pts):
			$tabParent = $tabParent + array($pts->codecat => $pts->nomcat);
		endforeach;
		$data['parent'] = $tabParent;

		$this->load->view('categorie/ajouter', $data);
	}else{
				redirect('admin/administrateur');
						}

}	
	
}


