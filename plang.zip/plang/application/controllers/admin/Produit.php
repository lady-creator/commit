<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produit extends CI_Controller {
/* ################### page :: methode pour lister ################### */
public function __construct(){
	        parent::__construct();
	 if($_SESSION['id']==NULL){
				redirect('admin/administrateur');
						}
	   		 }
	public function index($offset=0)
	{
		
		$produit =$this->M_produit->getProduit();
			$this->load->library('pagination');
		$config['base_url'] = site_url('admin/produit/indexp');
		$config['total_rows'] = count($produit);
		$config['per_page'] = 8;
		$config['reuse_query_string'] = TRUE;
		$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
		//$data['stagiaire'] = $this->M_stagiaire->getAll($config['per_page'],$offset);
		$data['produits'] =  $this->M_produit->getAl($config['per_page'],$offset);
		$this->pagination->initialize($config);
		$data['links'] = $this->pagination->create_links();
			             
			            
		$data['titre'] = $this->lang->line('affich_pro');

		$this->load->view('produit/liste', $data);
		
	}
	public function listeA($offset=0)
	{
		
		    $prod = $this->M_produit->getProduit();
		    $config['base_url'] = base_url('admin/Produit/listeA');

		    $this->load->library('pagination');
		
		$config['total_rows'] = count($prod);
		$config['per_page'] = 7;
		$config['reuse_query_string'] = TRUE;
		$config['full_tag_open'] = '<div class="pagination sdsds">';
		$config['full_tag_close'] = '</div>';
		
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<button class="firstlink">';
		$config['first_tag_close'] = '</button>';
		
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<button class="lastlink">';
		$config['last_tag_close'] = '</button>';
		
		$config['next_link'] = 'Next';
		$config['next_tag_open'] = '<button class="nextlink">';
		$config['next_tag_close'] = '</button>';

		$config['prev_link'] = 'Prev Page';
		$config['prev_tag_open'] = '<button class="prevlink">';
		$config['prev_tag_close'] = '</button>';

		$config['cur_tag_open'] = '<button class="curlink">';
		$config['cur_tag_close'] = '</button>';

		$config['num_tag_open'] = '<button class="numlink">';
		$config['num_tag_close'] = '</button>';
		$results= $this->M_produit->getAl($config['per_page'],$offset);
		           		$data['produits'] = $this->M_produit->tabProduit($results);
			            
			             
			            $this->pagination->initialize($config);
			                 
			            // build paging links
			            $data["links"] = $this->pagination->create_links();
		$data['titre'] = $this->lang->line('affich_pro');
		$this->load->view('produit/listeA', $data);
		
	}
/* ################### page :: methode pour ajouter ################### */
	public function ajouter()
		{    /* ################### les conditions sur les champs ################### */
	
		$data['submit'] = $this->lang->line('AJOUTER');
		$data['action']='admin/produit/ajouter';
		$data['produits'] =$this->M_produit->getProduit();
			$this->form_validation->set_rules('monpt', 'lang:monpt', 'trim|is_unique[produit.monpt]|required');
			$this->form_validation->set_rules('descrppt', 'lang:descrppt', 'trim|required');
			$this->form_validation->set_rules('statutpt', 'lang:statutpt', 'required');
			$this->form_validation->set_rules('codecat', 'lang:nompt', 'trim|required');
			$this->form_validation->set_rules('qtept', 'lang:qtept', 'trim|required');
			$this->form_validation->set_rules('prixvtpt', 'lang:prixvtpt', 'trim|required');
		if($this->form_validation->run())
		{
		/* ################### récuperation des informations d'un champs insertion ################### */
			$produit = array(
					'idpt'=>rand(999999,9999999),
					'prixvtpt' => $this->input->post('prixvtpt'),
					'qtept' => $this->input->post('qtept'),
					'codecat' => $this->input->post('codecat'),
					'idfour' => $this->input->post('idfour'),
					'descrppt' => $this->input->post('descrppt'),
	   				'descrpp' => $this->input->post('descrpp'),
					'prixapt' => $this->input->post('prixapt'),
					'monpt' => $this->input->post('monpt'),
					'originept' => $this->input->post('originept'),
					'marquept' => $this->input->post('marquept'),
					'couleurpt' => $this->input->post('couleurpt'),
					'garantiept' => $this->input->post('garantiept'),
					'typept' => $this->input->post('typept'),
					'prixpromo' => $this->input->post('prixpromo'),
					'statutpt' => $this->input->post('statutpt'),	
					'datesavept' => date('Y-m-d'),
					'dateupdatept' => date('Y-m-d'),
			);
				if($this->M_produit->addProduit($produit))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('admin/produit/');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('admin/produit/ajouter');
				}
			}

			//faire un selection sur les categories pour mettre dans un input dropdownn dans la vue
				$cat = $this->M_categorie->getCategorie(array($this->db->where('parent !=' ,'0')));
				$tabParent = array('0' => $this->lang->line('select_cat'));
				foreach($cat as $pts):
					$tabParent = $tabParent + array($pts->codecat => $pts->nomcat);
				endforeach;
				$data['codecat'] = $tabParent;

				//selection les fournisseurs;
				$four = $this->M_fournisseur->getFournisseur();
				$tabParent = array('0' => $this->lang->line('select_four'));
				foreach($four as $pts):
					$tabParent = $tabParent + array($pts->idfour => $pts->nomfour);
				endforeach;
				$data['idfour'] = $tabParent;
				$data['titre'] = $this->lang->line('ajouter_pro');
				$this->load->view('produit/ajouter', $data);
				
			}
		/* ################### page :: methode pour modifier ################### */
		public function modifier($idpt)
		{
			
			$data['titre'] = 'modifier un produit Produit';
			$data['submit'] = $this->lang->line('MODIFIER');
			//l'action formulaire
			$data['action']='admin/produit/modifier/'.$idpt;
			$data['produits'] =$this->M_produit->getProduit(array('idpt'=>$idpt));
			$this->form_validation->set_rules('qtept', 'lang:qtept', 'required');
			$this->form_validation->set_rules('prixvtpt', 'lang:prixvtpt', 'required');
			if($this->form_validation->run())
			{
			/* ################### récuperation des informations d'un champs insertion ################### */
			foreach ($ros as $v) {
					$v->dateupdatept;
				}
			$produit = array(
				'idpt'=>$idpt,
				'prixvtpt' => $this->input->post('prixvtpt'),
				'qtept' => $this->input->post('qtept'),
				'codecat' => $this->input->post('codecat'),
				'idfour' => $this->input->post('idfour'),
				'descrppt' => $this->input->post('descrppt'),
				'prixapt' => $this->input->post('prixapt'),
				'monpt' => $this->input->post('monpt'),
				'originept' => $this->input->post('originept'),
				'marquept' => $this->input->post('marquept'),
				'couleurpt' => $this->input->post('couleurpt'),
				'garantiept' => $this->input->post('garantiept'),
				'typept' => $this->input->post('typept'),
				'prixpromo' => $this->input->post('prixpromo'),
				'statutpt' => $this->input->post('statutpt'),	
				'datesavept' => date('Y-m-d'),
				'dateupdatept' => $v->dateupdatept,
			);
			if($this->M_produit->updateProduit($produit))
			{
				$this->session->set_flashdata('success', 'information a été modifié');
				
				redirect('admin/produit/');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit');
				//echo "noijn";
			}
		}
				//selection les fornisseur
		$four = $this->M_fournisseur->getFournisseur();
		$tabParent = array('0' => $this->lang->line('select_four'));
		foreach($four as $pts):
			$tabParent = $tabParent + array($pts->idfour => $pts->nomfour);
		endforeach;
		$data['idfour'] = $tabParent;
		//faire un selection sur les categories pour mettre dans un input dropdownn dans la vue
		$cat = $this->M_categorie->getCategorie(array($this->db->where('parent !=' ,'0')));
		$tabParent = array('0' => $this->lang->line('select_cat'));
		foreach($cat as $pts):
			$tabParent = $tabParent + array($pts->codecat => $pts->nomcat);
		endforeach;
		$data['codecat'] = $tabParent;
		
		$this->load->view('produit/ajouter', $data);
		
	}


	public function visite()
	{
		
		$data['visite'] =$this->M_produit->getVisite();;
		$data['titre'] = $this->lang->line('Plang');
		
		$this->load->view('produit/visite', $data);
		
	}

	//information de la photo
	public function indexp($offset=0)
	{
		
		//$data['photos'] =$this->M_produit->getPhoto();
		$param['titre'] = $this->lang->line('affich_cat');
		$this->load->library('pagination');
		$config['base_url'] = site_url('admin/produit/indexp');
		$config['total_rows'] = count($this->M_produit->getPhoto());
		$config['per_page'] = 8;
		$config['reuse_query_string'] = TRUE;
		$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4 uk-text-success" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';	
		//$data['stagiaire'] = $this->M_stagiaire->getAll($config['per_page'],$offset);
		$param['photos'] =  $this->M_produit->getp($config['per_page'],$offset);
		$this->pagination->initialize($config);
		$param['links'] = $this->pagination->create_links();
		$this->load->view('photo/lister', $param);
	
	}

////////////////////////////////////
/*public function insere()
  {
   
      $config['upload_path'] = './docs/image';
      $config['allowed_types'] = 'jpg|png|jpeg|gif';
      $config['max_size'] = '2048';  //2MB max
      $config['max_width'] = '4480'; // pixel
      $config['max_height'] = '4480'; // pixel
      $config['file_name'] = $_FILES['photo']['name'];
      print_r($_FILES);
    
      $this->upload->initialize($config);

	    if (!empty($_FILES['photo']['name'])) {
	        if ( $this->upload->do_upload('photo') ) {
	            $foto = $this->upload->data();
	           /* $data = array(
	                          'name'       => $name,
                            'foto'       => $foto['file_name'],
	                          'alamat'     => $alamat,
	                        );
	            $data=array(
				'idpt'=> $this->input->post('idpt'),
				'datesavep' => date('Y-m-d'),
			'dateupdate' => date('Y-m-d'),
				'photo'=>$foto['file_name']
				//$_FIILES['photo']['name']
			);
							if($this->M_produit->addPhoto($data))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				//redirect('admin/produit/addp');
				print_r($phot);
				print_r($data);
	 		} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit');
			}
	        }else {
                 $this->load->view('photo/ajouter');
	        
	        }
	    }else {
         
          $this->load->view('photo/ajouter');
	    }

	    $cat = $this->M_produit->getProduit();
		$tabParent = array('codecat' => $this->lang->line('select_p'));
		foreach($cat as $pts):
			$tabParent = $tabParent + array($pts->idpt => $pts->monpt);
		endforeach;
		$data['idpt'] = $tabParent;
		$data['titre'] = $this->lang->line('ajouter_p');

		$this->load->view('photo/ajouter', $data);

  }
///////////////////////
*/



	public function addp()
  {
     $data['submit'] = $this->lang->line('AJOUTER');
      $config['upload_path'] = './docs/image';
      $config['allowed_types'] = 'jpg|png|jpeg|gif';
      $config['max_size'] = '2048';  //2MB max
      $config['max_width'] = '4480'; // pixel
      $config['max_height'] = '4480'; // pixel
      $config['file_name'] = $_FILES['photo']['name'];
      //$_FILES['photo']['name'];
      print_r($_FILES);
    
      $this->upload->initialize($config);
      $this->form_validation->set_rules('idpt', 'lang:idpt', 'required');
			
			if($this->form_validation->run())
			{

	    if (!empty($_FILES['photo']['name'])) {
	        if ( $this->upload->do_upload('photo') ) {
	            $foto = $this->upload->data();
	            $data=array(
				
				'idpt'=> $this->input->post('idpt'),
				'photo'=>$foto['file_name'],
				'datesavep' => date('Y-m-d'),
			'dateupdate' => date('Y-m-d')
			);
			if($this->M_produit->addPhoto($data))
			{
				$this->session->set_flashdata('success', 'information enregistrée');				print_r($data);
	 		} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit');
			}

	        }else {
                 $this->load->view('photo/ajouter');
	        }
	    }else {
         
         echo 'echec';

	    }
	}
//faire un selection pour mettre dans un input dropdown
		$cat = $this->M_produit->getProduit();
		$tabParent = array('codecat' => 'choissisez le nom du produit');
		foreach($cat as $pts):
			$tabParent = $tabParent + array($pts->idpt => $pts->monpt);
		endforeach;
		$data['idpt'] = $tabParent;
		$data['titre'] = $this->lang->line('ajouter_p');

		$this->load->view('photo/ajouter', $data);
  }
/* ################### page :: methode pour ajouter une photo ################### */
	/*-public function addp()
	{
		
		$this->form_validation->set_rules('idpt', 'lang:idpt', 'required');
		$this->form_validation->set_rules('photo', 'lang:photo', 'required');
		$data['submit'] = $this->lang->line('AJOUTER');

		//if($this->form_validation->run())
		//{
			
			 $config['upload_path']="./docs/image/";
			$config['allowed_types']='git/jpeg/jpg/png/jfif';
			$config['max_size']='2048';
			$config['max_width']='4480';
			$config['max_height']='4480';
			$config['file_name']=$_FILES['photo']['name'];
				$this->upload->initialize($config);

			//$this->load->library('upload',$config);
				/*if(!empty($_FILES['photo']['name'])){

						$data=$this->upload->data();
        $phot = array(
			'idpt'=> $this->input->post('idpt'),
		    'photo'=>$data ,
		    'datesavep' => date('Y-m-d'),
			'dateupdate' => date('Y-m-d')
			); 
 }
 
		}else{
			echo "echo verifier votre photo";
		}
			if($this->M_produit->addPhoto($phot))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				//redirect('admin/produit/addp');
				print_r($phot);
				print_r($data);
	 		} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit');
			}
		//}
		//faire un selection pour mettre dans un input dropdown
		$cat = $this->M_produit->getProduit();
		$tabParent = array('codecat' => $this->lang->line('select_p'));
		foreach($cat as $pts):
			$tabParent = $tabParent + array($pts->idpt => $pts->monpt);
		endforeach;
		$data['idpt'] = $tabParent;
		$data['titre'] = $this->lang->line('ajouter_p');

		$this->load->view('photo/ajouter', $data);
		
	}*/
/* ################### page :: methode pour modifier une photo ################### */
	public function modifierp($idp)
	{
	
		$data['submit']='MODIFIER';
		$data['titre'] = $this->lang->line('modif_pro');
		$data['action']= 'admin/produit/modifierp/'.$idp;
		$phot=$data['photos'] =$this->M_produit->getPhoto(array('idp'=>$idp));
		// 
		if($this->form_validation->run())
		{
			$photo = array(
				'idp'=> $idp,
			   'photo'=> $this->input->post('photo'),
			   'idpt'=> $this->input->post('idpt'),
			   'datesavep' => date('Y-m-d'),
				'dateupdate' => date('Y-m-d')
			);   
			if($this->M_produit->updatePhoto($photo))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/produit/addp');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit/');
			}
		}

		//faire un selection pour mettre dans un input dropdown
		$ph=array();
		foreach($phot as $p):
			$ph=$ph+array($p->idp=>$p->photo);
		endforeach;
		$data['photo']=$ph;
		//
		$cat = $this->M_produit->getPhoto();
		$tabParent = array('codecat' => $this->lang->line('select_p'));
		foreach($cat as $pts):
			$tabParent = $tabParent + array($pts->idp => $pts->photo);
		endforeach;
		$data['monpt'] = $tabParent;
		
		$this->load->view('photo/ajouter', $data);
		
	}

	public function deletep($idp){
		
	//	$phot =$this->M_produit->getPhoto(array('idp'=>$idp));

		if($this->M_produit->deletePhoto($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/produit/indexp');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit/indexp');
			}
		$this->load->view('admin/produit/');
		
	}

	public function delete($idpt){
			echo 'jj';
		if($this->M_produit->deleteProduit($idpt))
			{
				$phot =$this->M_produit->getPhoto(array('idpt'=>$idpt));
				$this->deletep($phot);
				echo "	jk";
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/produit/listeA');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/produit/listeA');
			}
		
		
	}
 public function search(){
						$this->form_validation->set_rules('nom', 'lang:nom', 'trim|htmlspecialchars|required');
           	if($this->form_validation->run())
			{	
				$nom=$this->input->post('nom');

		  $prod = $this->M_produit->getProduit(array('idpt'=>$nom));
			$data['produits'] = $this->M_produit->tabProduit($prod);
      		  }
			$data['titre'] = 'planG';

			$this->load->view('produit/search', $data);
			
}
}