<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Panier extends CI_Controller {
		/* ################### add panier  ##################*/
		public function ajouter($idpt){
			$data['titre'] = 'planG';
			$produits = $this->M_produit->getProduit(array('idpt' =>$idpt));
			$pi=$data['p'] = $this->M_produit->tabProduit($produits);
			//print_r($pi);
		 	$i=1;
			$produits =array(
				'photo'=>$pi[0]['photos'],
				'id'=>$pi[0]['idpt'],
				'price'=>$pi[0]['prixvtpt'],
				'qty'=>1,
				'qtept'=>$pi[0]['qtept'],
				'codecat'=>$pi[0]['codecat'],
				'name'=>$pi[0]['monpt'],
				'prixapt'=>$pi[0]['prixapt'],
				'originept'=>$pi[0]['originept'],
				'marquept'=>$pi[0]['marquept'],
				'couleurpt'=>$pi[0]['couleurpt'],
				'garantiep'=>$pi[0]['garantiept'],
				'typept'=>$pi[0]['typept'],
				'prixpromo'=>$pi[0]['prixpromo']	
			);
				if($this->cart->insert($produits)){
						     redirect(' ');
						}	
		}
		public function update(){

			$produits =array(
				'rowid'=>$this->input->post('rowid'),
				'qty' =>$this->input->post('qty')
			);
			
			if($this->cart->update ($produits))
				{
				redirect('accueil/panier');
				}
		}
		public function delete($rowid){
			
			$this->M_panier->deletePanier($rowid);
				
			redirect('accueil/panier');
		}
		public function deleteAll(){
			$this->M_panier->delete();
			redirect('Accueil/panier');
		}
}			