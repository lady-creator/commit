<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['useragent'] = 'CodeIgniter';
$config['protocol'] = 'smtp';
//$config['mailpath'] = '/usr/sbin/sendmail';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_user'] = 'florinesiewe@gmail.com';
$config['smtp_pass'] = 'florine1234/*/';
$config['smtp_port'] = '465'; 

$config['smtp_timeout'] = '5';
$config['wordwrap'] = TRUE;
$config['wrapchars'] = '76';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['validate'] = TRUE;
$config['priority'] = '3';
$config['crlf'] = "\r\n";
$config['newline'] = "\r\n";
$config['bcc_batch_mode'] = FALSE;
$config['bcc_batch_size'] = '200';
     
/*
 $config['newline'] = "\r\n"; //You must use double quotes on this one
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.gmail.com'; //Change for your specific needs
$config['smtp_port'] = 465; //Change for your specific needs
$config['smtp_user'] = 'test@test.com'; //Change for your specific needs
$config['smtp_pass'] = 'yourpassword'; //Change for your specific needs
$config['charset'] = 'iso-8859-1';
$config['mailtype'] = 'text'; //This can be set as 'html' too*/