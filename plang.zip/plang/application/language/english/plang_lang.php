<?php
/**
 * System messages translation for CodeIgniter(tm)
 * @author	CodeIgniter community
 * @copyright	Copyright (c) 2014-2019, British Columbia Institute of Technology (https://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 */
defined('BASEPATH') OR exit('No direct script access allowed');

//titre
$lang['ajouter_four']    = "Add new supplier";
$lang['ajouter_client'] = "INCRIPTION";
$lang['ajouter_cat']    = "Add new category";
$lang['ajouter_pro']    = "Add new product";
$lang['rmdp'] = "rewrite your password";
$lang['ajouter_admin'] = "Add new administrator";
$lang['con']="I read all the condition general of the sale and I agree" ;
$lang['MODIFIER']="UPDATE";
$lang['AJOUTER']="ADD";

$lang['tit']="MODIFICATION FORM";
$lang['titr']="REGISTRATION FORM";

$lang['livm'] = "house";
$lang['livagence'] = "agency";
$lang['modepayl']="delivery house";
$lang['modepayo']="orange money";
$lang['modepaym']="mobile money";
$lang['con']="Agree the general condition";
$lang['affich_pro']="list of product";
$lang['affich_clt']="list of clients";
$lang['affich_cmd']="list of order";
$lang['affich_four']="list of supplier";
$lang['affich_admin']="list of administrators";
$lang['modif_cat']="list of categories";
$lang['modif_pro']="list of product";
$lang['modif_clt']="list of clients";
$lang['modif_cmd']="list of order";
$lang['modif_four']="list of supplier";
$lang['modif_admin']="list of administrators";
$lang['affich_cat']="list of categories";
$lang['nomcat'] = "Category name";
$lang ['parent'] = "The category rubric";
$lang ['codecat'] = "category";
//nouve
$lang ['select_parent'] = "Select Category parent";
$lang ['select_cat'] = "Select Category ";
$lang ['select_p'] = "Select produit";

// traduction de l'administrateur
$lang['idadmin'] = "Identify of the administrator *";
$lang['nomadmin'] = "Name of the administrator *";
$lang['prenomadmin'] = "First name of the administrator *";
$lang['datenaissadmin'] = "Date of birth of the administrator *";
$lang['villeadmin'] = "City of the administrator *";
$lang['sexeadmin'] = "Sex of the administrator *";
$lang['emailadmin'] = "Email address of the administrator :**";
$lang['mdpadmin'] = "administrator password *";
$lang['teladmin'] = "administrator's phone *";
$lang['quatieradmin'] = "District of the administrator *";
$lang['statutadmin'] = "Status of the administrator *";
$lang['datesaveadmin'] = "Administrator registration date *";
$lang['dateupdateadmin'] = "Date of modification of the administrator *";

//fournisseur
$lang['idfour'] = "Supplier identifier";
$lang['nomfour'] = "Name of the supplier *";
$lang['prenomfour'] = "First name of supplier *";
$lang['datenaissfour'] = "Date of birth of the supplier *";
$lang['villefour'] = "City of the supplier *";
$lang['quartierfour'] = "Supplier's district *";
$lang['sexefour'] = "Sexe of the supplier *";
$lang['emailfour'] = "Supplier email address";
$lang['mdpfour'] = "Supplier password *";
$lang['datesavefour'] = "Date of registration of the supplier";
$lang['dateupdatefour'] = "Supplier modification date";
$lang['telephonefour'] = "supplier's telephone *";
$lang['statutfour'] = "supplier status *";
//traduction des produit
$lang['idpt'] = "product identifier";
$lang['prixvtpt'] = "Sale price of the product *";
$lang['qtept'] = "Quantity of the product *";
$lang['photopt'] = "Photo of the product *";
$lang['nomcat'] = "Product name *";
$lang['idfour'] = "Supplier identifier";
$lang['datesavept'] = "Date of product registration";
$lang['dateupdatept'] = "Date of product modification";
$lang['descrppt'] = "Product description *";
$lang['prixapt'] = "Purchase price of the product";
$lang['monpt'] = "Product name *";
$lang['originept'] = "Origin of the product";
$lang['marquept'] = "Brand of the product";
$lang['couleurpt'] = "Product color *";
$lang['garantiept'] = "Guarantee of the product";
$lang['typept'] = "Type of product";
$lang['prixpromo'] = "Promotional price of the product";
$lang['statutpt'] = "product status";

// translation of the client table
$lang['idclient'] = "Identify of the client";
$lang['nomclt'] = "Name of the client *";
$lang['prenomclt'] = "First name of client *";
$lang['datenaissclt'] = "Client's date of birth *";
$lang['villeclient'] = "City *";
$lang['quartierclt'] = "District *";
$lang['sexeclt'] = "Gender of client *";
$lang['sexeh'] = "Man";
$lang['sexef'] = "Woman";
$lang['emailclt'] = "Client email address *";
$lang['mdpclt'] = "client password *";
$lang['datesaveclt'] = "date of client registration";
$lang['dateupdateclt'] = "Customer modification date";
$lang['telclt'] = "customer phone *";
$lang['statutclt'] = "client status";

// translation of the order
$lang['codecmd'] = "the order code *";
$lang['idclient'] = "Customer identifier *";
$lang['datecm'] = "Date when the order was placed *";
$lang['statutcmd'] = "Status of the order *";
$lang['ptcmd'] = "Order price *";
$lang['modliv'] = "Delivery method";
$lang['datepay'] = "Date of payment";
$lang['modepay'] = "Method of payment";
$lang['adressedeliv'] = "Delivery address";
$lang['nomcl'] = "Name of client *";
$lang['prenomcl'] = "Customer first name *";
$lang['telephonecl'] = "phone number *";
$lang['emailcl'] = "Email address";
$lang['villeliv'] = "City of delivery";
$lang['quatiercl'] = "Delivery district *";